
<center><b>Notice Board:</b><br><br>

Hostel respons on 15th February 2020<br><br>

sessionals to be announced soon<br><br>

student development seminar on 12th February'2020<br></center>