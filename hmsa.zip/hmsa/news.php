<center>NEWS</center>

<center><a href=""</a>Hostel Fest'2020<br><br>

<a href=""</a>Farewell'2020<br><br>

<a href=""</a>Result'2020<br><br>
 
<a href=""</a>Placement'2020<br><br></center>