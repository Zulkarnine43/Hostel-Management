<center><h1>Campus Drive</h1></center>

<center>City Hostel- <b>Accenture</b> - 17th July '2020<br><br>

Dhaka - <b>Wipro</b> - 28th July '2020<br><br>

Dhaka - <b>TCS</b> - 8th august '2020<br><br>

Dhaka- <b>Syntel</b> - 18th Aug '2020</center>