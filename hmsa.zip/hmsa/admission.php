<center><b>Admission 2020-21</b><br><br>

admission open from 15th july<br><br>

<b>PG cources-:</b><br><br>
Branches:<br>

Computer Science Engineering (120 seats)<br>
Electronics & Communications Engineering(120 seats)<br>
Information & Technology (60 seats)<br>
Electricak Engineering(60 seats)<br>
Civil Engineering(60 seats)<br>
Mechanical Engineerinh(60 seats)<br>
B.Pharma<br><br>

<b>UG cources-:</b><br><br>

</center>