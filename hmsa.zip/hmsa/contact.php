<h1 style="color:#000000"><b><center>Contact Details</center></b></h1>
<div align="center">
<p><b>Address :</b> City University Hostel
<p><b>Phone :</b> 01817<br>
<b>Mobile :</b>01817
</p>
<p><b>Email :</b> arif2600@gmail.com</p>
</p>
</div>